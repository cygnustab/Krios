package vmasurat.cygnus.com.vmasurat.broadcastreceiver;

import android.app.ActivityManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.gcm.GoogleCloudMessaging;

import org.json.JSONObject;

import java.util.List;

import vmasurat.cygnus.com.vmasurat.ConstantData;
import vmasurat.cygnus.com.vmasurat.CustomeObject.MemberProfile;
import vmasurat.cygnus.com.vmasurat.Popup2;
import vmasurat.cygnus.com.vmasurat.R;
import vmasurat.cygnus.com.vmasurat.Util;

public class GCMNotificationIntentService extends IntentService {

    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;

    public GCMNotificationIntentService() {
        super(ConstantData.GOOGLE_PROJECT_ID);
    }

    public static final String TAG = "GCMNotificationIntentService";


    String message = "";
    String fromid = "";
    String type = "";


    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);

        String messageType = gcm.getMessageType(intent);


        if (!extras.isEmpty()) {
            if (GoogleCloudMessaging.MESSAGE_TYPE_SEND_ERROR
                    .equals(messageType)) {

            } else if (GoogleCloudMessaging.MESSAGE_TYPE_DELETED
                    .equals(messageType)) {

            } else if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE
                    .equals(messageType)) {

                for (String key : extras.keySet()) {
                    Object value = extras.get(key);
                    Log.d("TAG", String.format("%s %s (%s)", key, value.toString(), value
                            .getClass().getName()));


                }

                try {


                    message = intent.getExtras().getString("message");

                    JSONObject notificationobj = new JSONObject(message);


                    message = notificationobj.getString("m");
                    fromid = notificationobj.getString("n");
                    type = notificationobj.getString("t");

//                    Log.v("BODId", "" + intent.getExtras().getString("BODId"));




                MemberProfile m = MemberProfile.getMemberProfileFromString(Util.getSharePrefranceData(GCMNotificationIntentService.this, ConstantData.SHARED_PREFERENCES_Profile_Object));


                if (m != null) {

                    if (isAppIsInBackground(GCMNotificationIntentService.this) == true) {
                        sendNotification("" + message);
                    } else {

                        Intent i = new Intent(this, Popup2.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ConstantData.jsonmsg = message;

                        ConstantData.fromname = fromid;

                        ConstantData.type = type;


                        startActivity(i);


                    }

                }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        }
        GcmBroadcastReceiver.completeWakefulIntent(intent);
    }


    private void sendNotification(String msg) {
        mNotificationManager = (NotificationManager) this
                .getSystemService(Context.NOTIFICATION_SERVICE);

//        Toast.makeText(GCMNotificationIntentService.this, msg, Toast.LENGTH_LONG).show();

        Intent in = new Intent(GCMNotificationIntentService.this, Popup2.class);
//        in.putExtra("Userid", fromid);
//        in.putExtra("message", message);
//        in.putExtra("type", type);

        ConstantData.jsonmsg = message;

        ConstantData.fromname = fromid;

        ConstantData.type = type;


        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, in, 0);

        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                    this)
                    .setSmallIcon(R.drawable.vmalogo)
                    .setContentTitle(getString(R.string.app_name))
                    .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
                    .setAutoCancel(true)
                    .setContentText(msg)
                    .setColor(Color.RED)
                    .setContentIntent(contentIntent)
                    .setNumber(2);
            mNotificationManager.notify(1000, mBuilder.build());

        } else {
            Notification notification = new Notification.Builder(this)
                    .setAutoCancel(true)

                    .setContentTitle(getString(R.string.app_name))
                    .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                    .setContentText(msg)
                    .setSmallIcon(R.drawable.vmalogo)
                    .setNumber(3)
                    .setContentIntent(contentIntent)
                    .setColor(Color.RED)
                    .build();
            mNotificationManager.notify(1000, notification);

        }

    }


    public static boolean isAppInForeground(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            return MyLifecycleHandler.isApplicationInForeground();
        } else {
            ActivityManager am = (ActivityManager) context
                    .getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
            if (!tasks.isEmpty()) {
                ComponentName topActivity = tasks.get(0).topActivity;
                if (topActivity.getPackageName().equals(
                        context.getPackageName())) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isAppIsInBackground(Context context) {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(context.getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(context.getPackageName())) {
                isInBackground = false;
            }
        }
        return isInBackground;
    }


}
