package vmasurat.cygnus.com.vmasurat.broadcastreceiver;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.AjaxStatus;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import org.json.JSONObject;

import java.io.IOException;

import vmasurat.cygnus.com.vmasurat.ConstantData;

/**
 * Created by Hitz on 22-Jun-15.
 */
public class RegisterGCM {


    public static String REG_ID = "regId";
    private Context context;
    private String regId;
    private GoogleCloudMessaging gcm;


    public RegisterGCM(Context context) {
        this.context = context;
        if (TextUtils.isEmpty(regId)) {
            regId = registerGCM();
            Log.d("RegisterActivity", "GCM RegId: " + regId);
        } else {
//            Toast.makeText(context,
//                    "RegId already available. RegId: " + regId,
//                    Toast.LENGTH_LONG).show();
        }
    }

    public static String getRegistrationId(Context context) {
        final SharedPreferences prefs = context.getSharedPreferences(
                RegisterGCM.class.getSimpleName(), Context.MODE_PRIVATE);
        String registrationId = prefs.getString(REG_ID, "");
        if (registrationId.isEmpty()) {
            Log.i("REG:-->", "Registration not found.");
            return "";
        }
        return registrationId;
    }

    public static String registerUserForPushNotification(String deviceToken, Context context, String userId, boolean islogin) {
        JSONObject requestData = new JSONObject();
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);


            final String deviceId = telephonyManager.getDeviceId();

            requestData.put("userid", userId);
            requestData.put("deviceId", deviceId);


            requestData.put("regId", islogin ? deviceToken : "");//regid

            Log.e("Data-->", "Mai   n data push notifcation " + requestData.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        final AQuery aq = new AQuery(context);
        aq.post(ConstantData.UpdateToken, requestData, JSONObject.class, new AjaxCallback<JSONObject>(
        ) {

            public void callback(String url, JSONObject json, AjaxStatus status) {


                if (json != null) {

                    try {

                        if (json.getString(ConstantData.RESULT).equalsIgnoreCase("success")) {
                            JSONObject jsonData = json.getJSONObject(ConstantData.DATA);

                            if (!jsonData.getBoolean(ConstantData.TOKEN)) {
//                                Toast.makeText(aq.getContext(), jsonData.getString(ConstantData.MESSAGE), Toast.LENGTH_LONG).show();
                            }
                        } else {
//                            Toast.makeText(aq.getContext(), "Error :" + json.toString(), Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception ex) {
//                        Toast.makeText(aq.getContext(), "Error :" + json.toString(), Toast.LENGTH_LONG).show();
                    }


                } else {
//                    Toast.makeText(aq.getContext(), "Error:" + status.getCode(), Toast.LENGTH_LONG).show();
                }
            }

        });


        return "";
    }

    public String registerGCM() {
        gcm = GoogleCloudMessaging.getInstance(context);
        regId = getRegistrationId(context);

        if (TextUtils.isEmpty(regId)) {

            registerInBackground();

            Log.d("RegisterActivity",
                    "registerGCM - successfully registered with GCM server - regId: "
                            + regId);
        } else {
//            Toast.makeText(context,
//                    "RegId already available. RegId: " + regId,
//                    Toast.LENGTH_LONG).show();
        }
        return regId;
    }

    private void registerInBackground() {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    if (gcm == null) {
                        gcm = GoogleCloudMessaging.getInstance(context);
                    }
                    regId = gcm.register(ConstantData.GOOGLE_PROJECT_ID);
                    Log.d("RegisterActivity", "registerInBackground - regId: "
                            + regId);
                    msg = "Device registered, registration ID=" + regId;

                } catch (IOException ex) {
                    msg = "Error :" + ex.getMessage();
                    Log.d("RegisterActivity", "Error: " + msg);
                }
                Log.d("RegisterActivity", "AsyncTask completed: " + msg);
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {

//                Toast.makeText(context,
//                        "Registered with GCM Server." + msg,
//                        Toast.LENGTH_LONG).show();
                saveRegisterId(context, regId);
            }
        }.execute(null, null, null);
    }

    private void saveRegisterId(Context context, String regId) {
        final SharedPreferences prefs = context.getSharedPreferences(
                RegisterGCM.class.getSimpleName(), Context.MODE_PRIVATE);

        Log.i("Saved:-->", "Saving regId on app version ");
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(REG_ID, regId);
        editor.commit();
    }

}
