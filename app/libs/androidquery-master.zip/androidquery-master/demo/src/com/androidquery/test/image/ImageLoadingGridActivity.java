package com.androidquery.test.image;

import android.os.Bundle;

import com.androidquery.R;

public class ImageLoadingGridActivity extends ImageLoadingList4Activity {

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		
	}
	
	protected int getContainer(){
		return R.layout.image_grid_activity;
	}
	
	

	
	
	
}
